package com.mystore.orders.service;

import com.mystore.orders.dto.OrderRequest;
import com.mystore.orders.dto.OrderResponse;
import com.mystore.orders.dto.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Random;

@Service
public class OrderService {

    String GET_PROD_URL  = "http://product-service/products/{id}";

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private DiscoveryClient discoveryClient ;

    public OrderResponse placeOrder(OrderRequest orderRequest) {

        ResponseEntity<Product> response = restTemplate.getForEntity(
                GET_PROD_URL,
                Product.class,
                orderRequest.getProductId()
        );

        Product product = response.getBody();

        if (product == null) {
            throw new RuntimeException("Product not found for ID: " + orderRequest.getProductId());
        }

        // 2. Calculate total price
        double totalPrice = orderRequest.getQty() * product.getPrice();

        // 3. Create OrderResponse
        OrderResponse orderResponse = new OrderResponse();
        orderResponse.setOrderId(new Random().nextLong()); // Just for demo, use DB sequence in real app
        orderResponse.setProductId(product.getId());
        orderResponse.setProductName(product.getName());
        orderResponse.setQty(orderRequest.getQty());
        orderResponse.setTotalPrice(totalPrice);

        return orderResponse;
        // TODO: 1. retrieve the product details from the product-service


        // TODO: 2. process the order (total price should be = quantity ordered * product price)


        // TODO: 3. return the response

    }

}
